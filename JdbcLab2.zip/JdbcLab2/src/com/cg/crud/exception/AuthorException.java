package com.cg.crud.exception;

public class AuthorException extends Exception {
	public AuthorException(String message) 
	{		
		super(message);
	}

}
