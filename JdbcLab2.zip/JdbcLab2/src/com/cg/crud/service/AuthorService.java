package com.cg.crud.service;

import java.util.List;

import com.cg.crud.bean.Author;
import com.cg.crud.exception.AuthorException;

public interface AuthorService {
	public void addAuthor(Author author)throws AuthorException;
	public List<Author> getAuthor()throws AuthorException;
	public void updateAuthor(Integer authorId,Integer newphoneNo)throws AuthorException;
	public void deleteEmployee(Integer authorId)throws AuthorException;


}
