package com.cg.crud.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.crud.bean.Author;
import com.cg.crud.dao.AuthorDao;
import com.cg.crud.dao.AuthorDaoImp;
import com.cg.crud.exception.AuthorException;


public class AuthorServiceImp implements AuthorService{

	AuthorDao dao = new AuthorDaoImp();
	
	@Override
	public void addAuthor(Author author) throws AuthorException {
		validateAuthor(author);
		dao.addAuthor(author);
		
	}

	@Override
	public List<Author> getAuthor() throws AuthorException {
		AuthorDao dao = new AuthorDaoImp();
		List<Author>list= dao.getAuthor();
		if(list==null || list.size()==0) 
			throw new AuthorException("No Author details found");
		
		return list;	
	}

	@Override
	public void updateAuthor(Integer authorId, Integer newphoneNo) throws AuthorException {
		int result=dao.updateAuthor(authorId, newphoneNo);
		if(result==0)
		{				
			throw new AuthorException("No employee found for the given empid");
		}	
		
	}

	@Override
	public void deleteEmployee(Integer authorId) throws AuthorException {
		int result=dao.deleteEmployee(authorId);
		if(result==0) {
			throw new AuthorException("No employee found for the given empid");
		}
	}
	
	/*******************************************************************************************************
	 - Function Name	: validateAuthor(Author author)
	 - Input Parameters	: Author author
	 - Return Type		: void
	 - Throws		    : AuthorException
	 - Author	      	: CAPGEMINI
	 - Creation Date	: 17/07/2019
	 - Description		: validates the Author object
	 ********************************************************************************************************/
	
	public void validateAuthor(Author author) throws AuthorException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating Author name
		if(!(isValidAuthorName(author.getFirstName()))) {
			validationErrors.add("\n Author Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		//Validating city
		if(!(isValidLastName(author.getLastName()))){
			validationErrors.add("\n Last Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		
		if(!validationErrors.isEmpty())
			throw new AuthorException(validationErrors +"");
	}

	public boolean isValidAuthorName(String authorName){
		Pattern namePattern=Pattern.compile("[A-Za-z]{3,}");
		Matcher nameMatcher=namePattern.matcher(authorName);
		return nameMatcher.matches();
	}
	public boolean isValidLastName(String lastName){
		Pattern namePattern=Pattern.compile("[A-Za-z]{3,}");
		Matcher nameMatcher=namePattern.matcher(lastName);
		return nameMatcher.matches();
	}

}
