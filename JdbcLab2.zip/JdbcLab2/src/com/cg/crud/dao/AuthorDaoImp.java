package com.cg.crud.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.crud.bean.Author;
import com.cg.crud.exception.AuthorException;
import com.cg.crud.util.DBConnection;

public class AuthorDaoImp implements AuthorDao{

	DBConnection dbConnection = new DBConnection();
	@Override
	public void addAuthor(Author author) throws AuthorException  {
		
	
		Connection con = null; 
		PreparedStatement ps=null;		
		ResultSet resultSet = null;
		int queryResult=0;
				
	
		try {
			
			con= dbConnection.getConnection();	
			String sql = "insert into author_master values(?,?,?,?,?);";
			ps = con.prepareStatement(sql);
			ps.setInt(1, author.getAuthorId());
			ps.setString(2, author.getFirstName());
			ps.setString(3, author.getMiddleName());
			ps.setString(4, author.getLastName());
			ps.setInt(5, author.getPhoneNo());
			queryResult=ps.executeUpdate();
		
			if(queryResult==0)
			{				
				throw new AuthorException("Inserting employee details failed ");
			}		
		}
		catch(SQLException | ClassNotFoundException sqlException)
		{			
			throw new AuthorException("Tehnical problem occured");
		}

		finally
		{
			try 
			{
				if(con!=null) {
					ps.close();
					con.close();
				}
			}
			catch (SQLException sqlException) 
			{
				throw new AuthorException("Error in closing db connection");

			}
		}		
		
		
	}

	@Override
	public List<Author> getAuthor() throws AuthorException {
		
		Connection con=null;

		PreparedStatement ps=null;
		ResultSet resultset = null;
		List<Author> authorList=new ArrayList<>();
		
		try
		{
			con=dbConnection.getConnection();
			ps = con.prepareStatement("Select * from author_master;");
			resultset=ps.executeQuery();
		
			
				System.out.println("Details of author");
				while(resultset.next())
				{
					Author author = new Author();
					author.setAuthorId(resultset.getInt("authorId"));
					author.setFirstName(resultset.getString("firstName"));
					author.setMiddleName(resultset.getString("middleName"));
					author.setLastName(resultset.getString("lastName"));
					author.setPhoneNo(resultset.getInt("phoneNo"));
					authorList.add(author);
				
				}

		} catch (SQLException | ClassNotFoundException sqlException) {

			throw new AuthorException("Tehnical problem occured. Refer log");
		}

		finally
		{
			try 
			{
				if(con!=null) {
					resultset.close();
					ps.close();
					con.close();
				}
			} 
			catch (SQLException e) 
			{			
				throw new AuthorException("Error in closing db connection");

			}
		}
		return authorList;
		
	}

	@Override
	public Integer updateAuthor(Integer authorId, Integer newphoneNo) throws AuthorException {
		Connection connection = null; 

		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;	

		int queryResult=0;
		try
		{		
			connection = dbConnection.getConnection();
			preparedStatement=connection.prepareStatement("Update author_master set phoneNo=? where authorId=?");
			preparedStatement.setInt(1, newphoneNo);
			preparedStatement.setInt(2, authorId);
			queryResult=preparedStatement.executeUpdate();
			
		}
		catch(SQLException | ClassNotFoundException sqlException)
		{			
			throw new AuthorException("Tehnical problem occured");
		}

		finally
		{
			try 
			{
				if(connection!=null) {
					preparedStatement.close();
					connection.close();
				}
			}
			catch (SQLException sqlException) 
			{

				throw new AuthorException("Error in closing db connection");

			}
		}
		return queryResult;
	}

	@Override
	public Integer deleteEmployee(Integer authorId) throws AuthorException {
		Connection connection = null; 

		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;	

		int queryResult=0;
		try
		{		
			connection = DBConnection.getConnection();	
			preparedStatement=connection.prepareStatement("delete from author_master where authorId=?");

			preparedStatement.setInt(1,authorId);

			queryResult=preparedStatement.executeUpdate();


		}
		catch(SQLException | ClassNotFoundException sqlException)
		{			
			throw new AuthorException("Tehnical problem occured");
		}

		finally
		{
			try 
			{
				if(connection!=null) {
					preparedStatement.close();
					connection.close();
				}
			}
			catch (SQLException sqlException) 
			{

				throw new AuthorException("Error in closing db connection");

			}
		}
		return queryResult;
	}

	
}
