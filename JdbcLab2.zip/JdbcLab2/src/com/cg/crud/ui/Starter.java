package com.cg.crud.ui;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.crud.bean.Author;
import com.cg.crud.exception.AuthorException;
import com.cg.crud.service.AuthorServiceImp;



public class Starter {
	 static AuthorServiceImp service = new AuthorServiceImp();
	public static void showMenu() {
		System.out.println("---------DashBoard---------");
		System.out.println("01. Add an Author");
		System.out.println("02. Retrieve Author");
		System.out.println("03. Update an Author");
		System.out.println("04. Delete an Author");
		System.out.println("05. Exit");
		System.out.print("Enter Your Choice : ");
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int choice;
		while (true) {
			showMenu();
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				try {
					System.out.println("------Enter Employee Details-------");
					
					System.out.println("Enter author id: ");
					Integer authorId=sc.nextInt();
					sc.nextLine();
					System.out.println("Enter author First Name: ");
					String firstName=sc.next();
					System.out.println("Enter author Middle Name: ");
					String middleName=sc.next();
					sc.nextLine();
					System.out.println("Enter author Last Name: ");
					String lastName=sc.next();
					System.out.println("Enter author phone number: ");
					int phoneNo=sc.nextInt();
					
					Author a=new Author();
				    a.setAuthorId(authorId);
				    a.setFirstName(firstName);
				    a.setMiddleName(middleName);
				    a.setLastName(lastName);
				    a.setPhoneNo(phoneNo);
					service.addAuthor(a);				
					System.out.println("author added successfully");
					break;
				}
				catch(AuthorException e) {
					System.out.println("Error : "+e.getMessage());
				}
				break;
			
			case 2:
				
				try {
					System.out.println("------Retrive Author Details------");
					List<Author> list = list = service.getAuthor();		
					for (Author author : list) {
						System.out.println(author.getAuthorId()+" -- "+author.getFirstName()+ " -- "+author.getMiddleName()+" -- "+author.getLastName()+" -- "+author.getPhoneNo());
					}
					
					break;

				}catch(AuthorException e) {
					System.out.println("Error : "+e.getMessage());
				}
				break;
			
			case 3:
				try {
					System.out.println("------Author Updated Successfully------");
					System.out.println("Enter author id: ");
					Integer authorId=sc.nextInt();
					sc.nextLine();
					System.out.println("Enter author new phone number: ");
					Integer newphoneNo=sc.nextInt();
					
					service.updateAuthor(authorId, newphoneNo);
					System.out.println("phone number details updated successfully");
					
				}catch(AuthorException e) {
					System.out.println("Error : "+e.getMessage());
				}
				break;
			
			case 4:
				try{
					System.out.println("------Deleting an Author------");				
					System.out.println("Enter author id: ");
					Integer authorId=sc.nextInt();
					sc.nextLine();
					service.deleteEmployee(authorId);
					System.out.println("author  deleted successfully");
				
				}catch(Exception e) {
					System.out.println("Error : "+e.getMessage());
				}
				break;
				
			case 5:
				sc.close();
				System.exit(0);

			default:
				System.out.println("Wrong Entry");			
			}
				
		}	
		
	}

}
